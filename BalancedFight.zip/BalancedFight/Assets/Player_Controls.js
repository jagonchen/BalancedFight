﻿#pragma strict

var moveRigth : KeyCode;
var moveLeft    : KeyCode;

var speed : float = 10;

function Start () {
	
}

function Update () {

    if (Input.GetKey(moveRigth)){

    	GetComponent.<Rigidbody2D>().velocity.x = speed;


    } else if(Input.GetKey(moveLeft)){
    	GetComponent.<Rigidbody2D>().velocity.x  = speed * -1;
    } else {

    	GetComponent.<Rigidbody2D>().velocity.x  = 0;
    }
	
}
