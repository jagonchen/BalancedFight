﻿#pragma strict
var enemy : GameObject;



function Start () {
	
}

function Update () {


	
}

function OnTriggerEnter(other : Collider){
	
	if (other.gameObject.tag == "Elenor_Abernathy"){
		Destroy(gameObject);
	}


}

