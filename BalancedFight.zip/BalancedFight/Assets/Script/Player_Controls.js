﻿#pragma strict

//Se declaran las variables para mover al personaje
var moveRigth 	: KeyCode;
var moveLeft    : KeyCode;
var jumpUp		: KeyCode;
var hit			: KeyCode;
var speed 		: float = 10f;
var fallMultiplier : float = 2.5f;
var lowJumMultiplier : float = 2f;
var jumpForce : float = 5f;
var fistVelocity : float = 1f;
var fistInMem : GameObject;
var fistInScene : GameObject;

function Start () {
}

var isInJump : boolean = false;
function Update () {

	fistInMem  = Resources.Load("fist_prefab", GameObject);


	var collider2D = GetComponent.<Collider2D>();

	if (Physics2D.IsTouchingLayers(collider2D, LayerMask.GetMask("Ground")))
	{
		//Debug.Log("Colliding");
		isInJump = false;

		}

    if (Input.GetKey(moveLeft)){

    	GetComponent.<Rigidbody2D>().velocity.x = speed;

    } else if(Input.GetKey(jumpUp) && isInJump == false){

    	GetComponent.<Rigidbody2D>().velocity  = Vector2.up * jumpForce;
    	isInJump = true;

    }    else if(Input.GetKey(moveRigth)){

    	GetComponent.<Rigidbody2D>().velocity.x  = speed * -1;

    }  else if (GetComponent.<Rigidbody2D>().velocity.y < 0){
    	
		GetComponent.<Rigidbody2D>().velocity += Vector2.up * Physics2D.gravity.y * (fallMultiplier -1) * Time.deltaTime;

    } else if(GetComponent.<Rigidbody2D>().velocity.y > 0 && !Input.GetKey(jumpUp)){

		GetComponent.<Rigidbody2D>().velocity += Vector2.up * Physics2D.gravity.y * (lowJumMultiplier -1) * Time.deltaTime;

    } else {

    	GetComponent.<Rigidbody2D>().velocity.x  = 0;

    }


    if (Input.GetKeyUp(hit)){

    	
    	fistInScene = GameObject.Instantiate(fistInMem, transform.position,Quaternion.identity);


    }

    if (fistInScene != null){

    	fistInScene.transform.Translate(fistVelocity * Time.deltaTime,0,0);



    }
	
}
